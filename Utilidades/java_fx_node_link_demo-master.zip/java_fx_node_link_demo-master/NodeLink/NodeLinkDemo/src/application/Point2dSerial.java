package application;

import java.io.Serializable;

import javafx.geometry.Point2D;

public class Point2dSerial extends Point2D implements Serializable {

	public Point2dSerial(double x, double y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
}
