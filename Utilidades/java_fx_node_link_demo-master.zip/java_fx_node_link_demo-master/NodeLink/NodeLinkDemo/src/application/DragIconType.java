package application;

public enum DragIconType {
	cubic_curve,	
	red,
	green,
	blue,
	black,
	yellow,
	purple,
	grey
}
