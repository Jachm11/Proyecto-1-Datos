package application;

public enum DragIconType {
	red,
	green,
	blue,
	black,
	yellow,
	purple,
	grey
}
